a, c = 32, -3
b = a << 2
a >>= 3
c = c << 2
print(a, b, c)
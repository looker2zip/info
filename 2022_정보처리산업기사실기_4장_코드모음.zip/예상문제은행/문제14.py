a, b = 2, 3
c = a & b
print(c)
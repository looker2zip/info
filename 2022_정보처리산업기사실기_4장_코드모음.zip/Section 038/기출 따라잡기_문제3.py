x, y = 100, 200
print(x==y)
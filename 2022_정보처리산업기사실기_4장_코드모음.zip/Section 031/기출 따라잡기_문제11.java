public class Test {
	public static void main(String[] args) {
		int n = 17;
		n += 1;
		n -= 2;
		n *= 3;
		n /= 4;
		n %= 5;
			System.out.println(n);
	}
}
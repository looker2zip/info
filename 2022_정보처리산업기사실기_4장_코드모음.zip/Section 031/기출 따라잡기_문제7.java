public class Test {
	public static void main(String []args) {
		int x = 1;
		System.out.println(!(x > 0));
		System.out.println(x > 0 || x < 4);
		System.out.println(x << 2);
		System.out.println(x & 2);
		System.out.println(x % 3);
	}
}